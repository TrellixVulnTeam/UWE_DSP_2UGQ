from django.apps import AppConfig


class RestockingConfig(AppConfig):
    name = 'restocking'
