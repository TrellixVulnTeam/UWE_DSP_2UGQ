from restocking.views.admin_navigation import *
from restocking.views.rest import *
from restocking.views.manager_navigation import *
from restocking.views.forbidden_functions import *
from restocking.views.data_creation import *